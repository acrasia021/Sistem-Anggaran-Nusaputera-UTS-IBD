<div class="table-responsive service">
                            <table class="table table-bordered table-hover  mt-3 text-nowrap css-serial">
                                
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Agenda</th>
                                    <th scope="col">Jumlah Pemasukan</th>
                                    <th scope="col">Tanggal</th>
                                </tr>

                            </thead>
                            <?php
                            if(isset($_GET['cari'])){
                                $cari=mysqli_real_escape_string($conn, $_GET['cari']);
                                $search=mysqli_query($conn, "select * from tbl_realisasi where keterangan like '%".$cari."%'");
                                if(mysqli_num_rows($search) > 0){
                                    echo "<div class='col-md-10 col-sm-12 col-xs-12 ml-5'>";
                                    echo "<div class='alert alert-primary mt-4 ml-5' role='alert'>";
                                    echo "<p><center>Data Yang Anda Cari  Ditemukan</center></p>";
                                    echo   "</div>";
                                    echo "</div>";
                                }else{
                                    echo "<div class='col-md-10 col-sm-12 col-xs-12 ml-5'>";
                                    echo "<div class='alert alert-danger mt-4 ml-5' role='alert'>";
                                    echo "<p><center>$cari Yang Anda Cari Tidak Ditemukan</center></p>";
                                    echo   "</div>";
                                    echo "</div>";
                                }
                            }else{
                                $search=mysqli_query($conn, "select * from tbl_anggaran limit $start, $hal");
                            }
                            if(mysqli_num_rows($search)){
                                while($row = mysqli_fetch_array($search)){
                                    ?>
                                    <tbody>
                                        <tr>
                                            <th scope="row"><?php echo $row['id_anggaran'] ?></th>
                                            <td><?php echo $row['keterangan'] ?></td>
                                            <td><?php echo number_format($row['nilai']) ?></td>
                                            <td><?php echo $row['tanggal'] ?></td>
                                </tr>
                            </tbody>
                            <?php }}elseif(mysqli_num_rows($search) <= 0 AND !$cari){
                                echo "<div class='col-md-10 col-sm-12 col-xs-12 ml-5'>";
                                echo "<div class='alert alert-danger mt-4 ml-5' role='alert'>";
                                echo "<p><center>Data Anda Masih Kosong</center></p>";
                                echo "</div>";
                                echo "</div>";
                                }?>
                                </table>
                            </div>