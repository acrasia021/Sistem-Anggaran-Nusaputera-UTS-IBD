<?php
$servername = "localhost";
$username = "kamz3581_db_keuangan";
$password = "dbkeuangan";

// Create connection
$conn = new mysqli($servername, $username, $password,"kamz3581_db_keuangan");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>